<template>
  <div>
    <div class="flex justify-between items-center mb-6">
      <h1 class="text-2xl font-bold">PC Management</h1>
      <button @click="showAddModal = true" class="btn btn-primary">
        + Add PC
      </button>
    </div>
    
    <!-- PC Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <div
        v-for="pc in pcs"
        :key="pc.id"
        class="card cursor-pointer hover:shadow-lg transition-shadow"
        @click="editPC(pc)"
      >
        <div class="flex justify-between items-start mb-4">
          <div>
            <h3 class="font-semibold text-lg">{{ pc.name }}</h3>
            <p class="text-sm text-gray-500">PC #{{ pc.pc_number }}</p>
          </div>
          <span
            class="px-2 py-1 rounded-full text-xs"
            :class="getStatusClass(pc)"
          >
            {{ getStatusText(pc) }}
          </span>
        </div>
        
        <div class="space-y-2 text-sm">
          <div class="flex justify-between">
            <span class="text-gray-500">IP Address:</span>
            <span>{{ pc.ip_address || 'N/A' }}</span>
          </div>
          <div class="flex justify-between">
            <span class="text-gray-500">Client Running:</span>
            <span :class="pc.client_running ? 'text-green-600' : 'text-red-600'">
              {{ pc.client_running ? 'Yes' : 'No' }}
            </span>
          </div>
          <div class="flex justify-between">
            <span class="text-gray-500">Ticket:</span>
            <span v-if="pc.session_code" class="font-mono text-sm">
              {{ pc.session_code }}
            </span>
            <span v-else class="text-gray-500">—</span>
          </div>
          <div class="flex justify-between">
            <span class="text-gray-500">Session:</span>
            <span v-if="pc.has_active_session" :class="sessionClass(pc)">
              {{ sessionLabel(pc) }} ({{ formatTime(pc.time_left) }} left)
            </span>
            <span v-else class="text-gray-500">None</span>
          </div>
          <div class="flex justify-between">
            <span class="text-gray-500">Banned:</span>
            <span :class="pc.is_banned ? 'text-red-600 font-bold' : 'text-gray-500'">
              {{ pc.is_banned ? 'YES' : 'No' }}
            </span>
          </div>
        </div>
        
        <div class="mt-4 pt-4 border-t flex flex-wrap justify-end gap-2">
          <button
            v-if="pc.has_active_session"
            @click.stop="forceLock(pc)"
            class="text-sm px-3 py-1 rounded bg-amber-100 text-amber-700"
          >
            Force Lock
          </button>
          <button
            v-if="pc.has_active_session"
            @click.stop="forceLogout(pc)"
            class="text-sm px-3 py-1 rounded bg-orange-100 text-orange-700"
          >
            Force Logout
          </button>
          <button
            @click.stop="refreshRules(pc)"
            class="text-sm px-3 py-1 rounded bg-purple-100 text-purple-700"
          >
            Refresh Rules
          </button>
          <button
            v-if="!pc.is_banned"
            @click.stop="banPC(pc)"
            class="text-sm px-3 py-1 rounded bg-red-100 text-red-600"
          >
            Ban
          </button>
          <button
            v-else
            @click.stop="unbanPC(pc)"
            class="text-sm px-3 py-1 rounded bg-green-100 text-green-600"
          >
            Unban
          </button>
          <button
            @click.stop="generateMasterCode(pc)"
            class="text-sm px-3 py-1 rounded bg-blue-100 text-blue-600"
          >
            Generate Code
          </button>
        </div>
      </div>
    </div>
    
    <!-- Add/Edit Modal -->
    <div
      v-if="showAddModal || editingPC"
      class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
    >
      <div class="card w-full max-w-3xl max-h-[90vh] overflow-y-auto">
        <h2 class="text-xl font-semibold mb-4">
          {{ editingPC ? 'Edit PC' : 'Add New PC' }}
        </h2>
        
        <form @submit.prevent="savePC">
          <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-2">
              PC Name
            </label>
            <input
              v-model="formData.name"
              type="text"
              class="input"
              placeholder="e.g., PC-01"
              required
            />
          </div>
          
          <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-2">
              PC Number
            </label>
            <input
              v-model.number="formData.pc_number"
              type="number"
              class="input"
              placeholder="e.g., 1"
              required
            />
          </div>
          
          <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-2">
              IP Address
            </label>
            <input
              v-model="formData.ip_address"
              type="text"
              class="input"
              placeholder="e.g., 192.168.1.100"
            />
          </div>
          
          <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-2">
              MAC Address
            </label>
            <input
              v-model="formData.mac_address"
              type="text"
              class="input"
              placeholder="e.g., AA:BB:CC:DD:EE:FF"
            />
          </div>

          <div v-if="editingPC" class="mb-4 border-t pt-4">
            <h3 class="font-medium mb-3">Per-PC App Policy</h3>
            <div class="mb-3">
              <label class="block text-sm font-medium text-gray-700 mb-2">Mode</label>
              <select v-model="appPolicy.mode" class="input">
                <option value="blocklist">Blocklist</option>
                <option value="allowlist">Allowlist</option>
                <option value="hybrid">Hybrid</option>
              </select>
            </div>
            <div class="mb-3">
              <label class="block text-sm font-medium text-gray-700 mb-2">
                Allowed apps (one per line, e.g. steam.exe)
              </label>
              <textarea
                v-model="allowedAppsText"
                class="input"
                rows="3"
                placeholder="steam.exe"
              />
            </div>
            <div class="mb-3">
              <label class="block text-sm font-medium text-gray-700 mb-2">
                Blocked apps (one per line)
              </label>
              <textarea
                v-model="blockedAppsText"
                class="input"
                rows="2"
                placeholder="taskmgr.exe"
              />
            </div>

            <div class="mb-3 border rounded-lg p-3 bg-gray-50">
              <div class="flex items-center justify-between mb-3 gap-2">
                <div>
                  <h4 class="font-medium">Apps on this PC</h4>
                  <p class="text-xs text-gray-500">
                    <span v-if="scannedAt">Last scan: {{ formatDate(scannedAt) }}</span>
                    <span v-else>Not scanned yet — request a scan from the client</span>
                  </p>
                </div>
                <button
                  type="button"
                  class="text-sm px-3 py-1 rounded bg-indigo-100 text-indigo-700 whitespace-nowrap"
                  :disabled="scanLoading || !editingPC.client_running"
                  @click="scanPcApps"
                >
                  {{ scanLoading ? 'Scanning…' : 'Scan PC' }}
                </button>
              </div>

              <input
                v-model="appSearch"
                type="text"
                class="input mb-3"
                placeholder="Search apps…"
              />

              <div class="max-h-56 overflow-y-auto space-y-2">
                <div
                  v-for="app in filteredPcApps"
                  :key="app.exe_name"
                  class="flex items-center justify-between gap-2 p-2 bg-white rounded border"
                >
                  <div class="min-w-0">
                    <div class="font-medium truncate">{{ app.name }}</div>
                    <div class="text-xs text-gray-500 font-mono">{{ app.exe_name }}</div>
                  </div>
                  <div class="flex items-center gap-2 shrink-0">
                    <span
                      class="text-xs px-2 py-0.5 rounded-full"
                      :class="appPolicyBadgeClass(app.policy_status)"
                    >
                      {{ appPolicyLabel(app.policy_status) }}
                    </span>
                    <button
                      type="button"
                      class="text-xs px-2 py-1 rounded bg-green-100 text-green-700"
                      @click="toggleAppPolicy(app.exe_name, 'allowed')"
                    >
                      Allow
                    </button>
                    <button
                      type="button"
                      class="text-xs px-2 py-1 rounded bg-red-100 text-red-700"
                      @click="toggleAppPolicy(app.exe_name, 'blocked')"
                    >
                      Block
                    </button>
                    <button
                      type="button"
                      class="text-xs px-2 py-1 rounded bg-gray-100 text-gray-600"
                      @click="toggleAppPolicy(app.exe_name, 'none')"
                    >
                      Clear
                    </button>
                  </div>
                </div>
                <div
                  v-if="filteredPcApps.length === 0"
                  class="text-center text-sm text-gray-500 py-4"
                >
                  No apps to show. Scan the PC while the client is running.
                </div>
              </div>
            </div>
          </div>
          
          <div class="flex justify-end space-x-2">
            <button
              type="button"
              @click="closeModal"
              class="px-4 py-2 text-gray-600 hover:text-gray-800"
            >
              Cancel
            </button>
            <button type="submit" class="btn btn-primary">
              {{ editingPC ? 'Update' : 'Add' }}
            </button>
          </div>
        </form>
      </div>
    </div>
    
    <!-- Master Code Modal -->
    <div
      v-if="showMasterCodeModal"
      class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
    >
      <div class="card w-full max-w-md">
        <h2 class="text-xl font-semibold mb-4">Generate Master Code</h2>
        
        <div class="mb-4">
          <p class="text-gray-600 mb-2">PC #{{ selectedPCForCode?.pc_number }} - {{ selectedPCForCode?.name }}</p>
          <label class="block text-sm font-medium text-gray-700 mb-2">
            Duration (minutes)
          </label>
          <input
            v-model.number="codeDuration"
            type="number"
            class="input"
            min="1"
            max="480"
          />
        </div>
        
        <div v-if="generatedCode" class="bg-green-50 border border-green-200 p-4 rounded mb-4">
          <p class="text-sm text-green-700">Generated Code:</p>
          <p class="text-2xl font-mono font-bold text-green-800">{{ generatedCode }}</p>
          <p class="text-xs text-green-600">Expires in {{ codeDuration }} minutes</p>
        </div>
        
        <div class="flex justify-end space-x-2">
          <button
            type="button"
            @click="showMasterCodeModal = false"
            class="px-4 py-2 text-gray-600 hover:text-gray-800"
          >
            Close
          </button>
          <button
            v-if="!generatedCode"
            @click="generateCode"
            class="btn btn-primary"
          >
            Generate
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import api from '@/services/api'

const pcs = ref([])
const showAddModal = ref(false)
const editingPC = ref(null)
const showMasterCodeModal = ref(false)
const selectedPCForCode = ref(null)
const codeDuration = ref(60)
const generatedCode = ref('')

const appPolicy = ref({
  mode: 'blocklist',
  allowed_apps: [],
  blocked_apps: [],
})
const allowedAppsText = ref('')
const blockedAppsText = ref('')
const pcApps = ref([])
const appSearch = ref('')
const scannedAt = ref(null)
const scanLoading = ref(false)
let scanPollTimer = null

const formData = ref({
  name: '',
  pc_number: 1,
  branch_id: 1,
  ip_address: '',
  mac_address: '',
})

const fetchPCs = async () => {
  try {
    const response = await api.get('/api/pcs/status')
    pcs.value = response.data
  } catch (error) {
    console.error('Failed to fetch PCs:', error)
  }
}

const getStatusClass = (pc) => {
  if (pc.is_alarming) return 'bg-red-100 text-red-700'
  if (pc.is_banned) return 'bg-orange-100 text-orange-700'
  if (!pc.client_running) return 'bg-yellow-100 text-yellow-700'
  if (pc.has_active_session) return 'bg-green-100 text-green-700'
  return 'bg-gray-100 text-gray-700'
}

const getStatusText = (pc) => {
  if (pc.is_alarming) return 'ALARM'
  if (pc.is_banned) return 'BANNED'
  if (!pc.client_running) return 'APP NOT RUNNING'
  if (pc.has_active_session) return 'ACTIVE'
  return 'IDLE'
}

const formatDate = (dateStr) => {
  if (!dateStr) return 'Never'
  return new Date(dateStr).toLocaleString()
}

const formatTime = (seconds) => {
  const mins = Math.floor(seconds / 60)
  return `${mins} min`
}

const sessionLabel = (pc) => {
  if (pc.session_status === 'paused') return 'Paused'
  return 'Active'
}

const sessionClass = (pc) => {
  if (pc.session_status === 'paused') return 'text-amber-600'
  return 'text-green-600'
}

const filteredPcApps = computed(() => {
  const query = appSearch.value.trim().toLowerCase()
  if (!query) return pcApps.value
  return pcApps.value.filter(
    (app) =>
      app.name.toLowerCase().includes(query) ||
      app.exe_name.toLowerCase().includes(query)
  )
})

const syncPolicyTextareas = (policy) => {
  allowedAppsText.value = (policy.allowed_apps || []).join('\n')
  blockedAppsText.value = (policy.blocked_apps || []).join('\n')
}

const appPolicyLabel = (status) => {
  const labels = {
    allowed_pc: 'Allowed',
    blocked_pc: 'Blocked',
    allowed_effective: 'Allowed (branch)',
    blocked_effective: 'Blocked (branch)',
    none: 'Default',
  }
  return labels[status] || 'Default'
}

const appPolicyBadgeClass = (status) => {
  if (status === 'allowed_pc' || status === 'allowed_effective') {
    return 'bg-green-100 text-green-700'
  }
  if (status === 'blocked_pc' || status === 'blocked_effective') {
    return 'bg-red-100 text-red-700'
  }
  return 'bg-gray-100 text-gray-600'
}

const fetchPcApps = async (pcId) => {
  try {
    const response = await api.get(`/api/pcs/${pcId}/apps`)
    pcApps.value = response.data.apps || []
    scannedAt.value = response.data.scanned_at || null
    if (response.data.pc_app_policy) {
      appPolicy.value = {
        mode: response.data.pc_app_policy.mode || appPolicy.value.mode,
        allowed_apps: response.data.pc_app_policy.allowed_apps || [],
        blocked_apps: response.data.pc_app_policy.blocked_apps || [],
      }
      syncPolicyTextareas(appPolicy.value)
    }
    return response.data
  } catch (error) {
    console.error('Failed to fetch PC apps:', error)
    return null
  }
}

const stopScanPoll = () => {
  if (scanPollTimer) {
    clearInterval(scanPollTimer)
    scanPollTimer = null
  }
  scanLoading.value = false
}

const scanPcApps = async () => {
  if (!editingPC.value) return

  const previousScan = scannedAt.value
  scanLoading.value = true

  try {
    await api.post(`/api/pcs/${editingPC.value.id}/commands/scan-apps`)

    let attempts = 0
    stopScanPoll()
    scanLoading.value = true
    scanPollTimer = setInterval(async () => {
      attempts += 1
      const data = await fetchPcApps(editingPC.value.id)
      if (
        (data?.scanned_at && data.scanned_at !== previousScan) ||
        attempts >= 15
      ) {
        stopScanPoll()
      }
    }, 2000)
  } catch (error) {
    console.error('Failed to scan PC apps:', error)
    stopScanPoll()
    alert(error.response?.data?.detail || 'Could not start app scan')
  }
}

const toggleAppPolicy = async (exeName, list) => {
  if (!editingPC.value) return

  try {
    const response = await api.post(
      `/api/pcs/${editingPC.value.id}/app-policy/toggle`,
      { exe_name: exeName, list }
    )
    appPolicy.value = {
      ...appPolicy.value,
      ...response.data.app_policy,
    }
    syncPolicyTextareas(appPolicy.value)
    await fetchPcApps(editingPC.value.id)
  } catch (error) {
    console.error('Failed to update app policy:', error)
  }
}

const editPC = async (pc) => {
  editingPC.value = pc
  formData.value = { ...pc }
  appSearch.value = ''
  pcApps.value = []
  scannedAt.value = null
  try {
    const response = await api.get(`/api/pcs/${pc.id}/config`)
    const policy = response.data.pc_app_policy || {}
    appPolicy.value = {
      mode: policy.mode || 'blocklist',
      allowed_apps: policy.allowed_apps || [],
      blocked_apps: policy.blocked_apps || [],
    }
    syncPolicyTextareas(appPolicy.value)
    await fetchPcApps(pc.id)
  } catch (error) {
    console.error('Failed to load PC config:', error)
  }
}

const parseAppsList = (text) =>
  text
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)

const saveAppPolicy = async (pcId) => {
  await api.put(`/api/pcs/${pcId}/app-policy`, {
    app_policy: {
      mode: appPolicy.value.mode,
      allowed_apps: parseAppsList(allowedAppsText.value),
      blocked_apps: parseAppsList(blockedAppsText.value),
    },
  })
}

const closeModal = () => {
  stopScanPoll()
  showAddModal.value = false
  editingPC.value = null
  appPolicy.value = { mode: 'blocklist', allowed_apps: [], blocked_apps: [] }
  allowedAppsText.value = ''
  blockedAppsText.value = ''
  pcApps.value = []
  appSearch.value = ''
  scannedAt.value = null
  formData.value = {
    name: '',
    pc_number: 1,
    branch_id: 1,
    ip_address: '',
    mac_address: '',
  }
}

const savePC = async () => {
  try {
    if (editingPC.value) {
      await api.put(`/api/pcs/${editingPC.value.id}`, formData.value)
      await saveAppPolicy(editingPC.value.id)
    } else {
      await api.post('/api/pcs/', formData.value)
    }
    closeModal()
    fetchPCs()
  } catch (error) {
    console.error('Failed to save PC:', error)
  }
}

const forceLock = async (pc) => {
  try {
    await api.post(`/api/pcs/${pc.id}/commands/force-lock`)
    fetchPCs()
  } catch (error) {
    console.error('Failed to force lock:', error)
  }
}

const forceLogout = async (pc) => {
  try {
    await api.post(`/api/pcs/${pc.id}/commands/force-logout`)
    fetchPCs()
  } catch (error) {
    console.error('Failed to force logout:', error)
  }
}

const refreshRules = async (pc) => {
  try {
    await api.post(`/api/pcs/${pc.id}/commands/refresh-rules`)
  } catch (error) {
    console.error('Failed to refresh rules:', error)
  }
}

const banPC = async (pc) => {
  const reason = prompt('Enter reason for ban (optional):')
  
  try {
    await api.post(`/api/pcs/${pc.id}/ban`, { reason })
    fetchPCs()
  } catch (error) {
    console.error('Failed to ban PC:', error)
  }
}

const unbanPC = async (pc) => {
  try {
    await api.post(`/api/pcs/${pc.id}/unban`)
    fetchPCs()
  } catch (error) {
    console.error('Failed to unban PC:', error)
  }
}

const generateMasterCode = (pc) => {
  selectedPCForCode.value = pc
  codeDuration.value = 60
  generatedCode.value = ''
  showMasterCodeModal.value = true
}

const generateCode = async () => {
  try {
    const response = await api.post('/api/master-codes/generate', {
      pc_id: selectedPCForCode.value.id,
      duration_minutes: codeDuration.value,
    })
    generatedCode.value = response.data.code
  } catch (error) {
    console.error('Failed to generate code:', error)
  }
}

onMounted(fetchPCs)

onUnmounted(() => {
  stopScanPoll()
})
</script>
